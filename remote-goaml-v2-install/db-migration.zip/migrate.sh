#!/bin/bash
# =============================================================
# goAML-V2 — Apply database schemas
# Run from the app server where goaml-postgres and
# goaml-clickhouse containers are accessible
# =============================================================

set -e

POSTGRES_USER="goaml"
POSTGRES_PASSWORD="Asdf@1234"
POSTGRES_DB="goaml"
POSTGRES_HOST="localhost"
POSTGRES_PORT="5432"

CLICKHOUSE_USER="goaml"
CLICKHOUSE_PASSWORD="Asdf@1234"
CLICKHOUSE_HOST="localhost"
CLICKHOUSE_PORT="8123"

echo "=================================================="
echo " goAML-V2 Schema Migration"
echo "=================================================="

# PostgreSQL
echo ""
echo "→ Applying PostgreSQL schema..."
PGPASSWORD="$POSTGRES_PASSWORD" psql \
    -h "$POSTGRES_HOST" \
    -p "$POSTGRES_PORT" \
    -U "$POSTGRES_USER" \
    -d "$POSTGRES_DB" \
    -f schema_postgres.sql

echo "✓ PostgreSQL schema applied"

# ClickHouse
echo ""
echo "→ Applying ClickHouse schema..."
curl -s \
    "http://$CLICKHOUSE_HOST:$CLICKHOUSE_PORT/" \
    --user "$CLICKHOUSE_USER:$CLICKHOUSE_PASSWORD" \
    --data-binary @schema_clickhouse.sql

echo "✓ ClickHouse schema applied"

# Verify PostgreSQL tables
echo ""
echo "→ Verifying PostgreSQL tables..."
PGPASSWORD="$POSTGRES_PASSWORD" psql \
    -h "$POSTGRES_HOST" \
    -p "$POSTGRES_PORT" \
    -U "$POSTGRES_USER" \
    -d "$POSTGRES_DB" \
    -c "\dt" | grep -E "accounts|entities|transactions|alerts|cases|sar_reports|documents|screening_results"

# Verify ClickHouse tables
echo ""
echo "→ Verifying ClickHouse tables..."
curl -s \
    "http://$CLICKHOUSE_HOST:$CLICKHOUSE_PORT/?query=SHOW+TABLES+FROM+goaml" \
    --user "$CLICKHOUSE_USER:$CLICKHOUSE_PASSWORD"

echo ""
echo "=================================================="
echo " Schema migration complete"
echo "=================================================="
